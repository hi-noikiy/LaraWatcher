<link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/mdui@1.0.0/dist/css/mdui.min.css"
    integrity="sha384-2PJ2u4NYg6jCNNpv3i1hK9AoAqODy6CdiC+gYiL2DVx+ku5wzJMFNdE3RoWfBIRP"
    crossorigin="anonymous"
/>
<script
    src="https://cdn.jsdelivr.net/npm/mdui@1.0.0/dist/js/mdui.min.js"
    integrity="sha384-aB8rnkAu/GBsQ1q6dwTySnlrrbhqDwrDnpVHR2Wgm8pWLbwUnzDcIROX3VvCbaK+"
    crossorigin="anonymous"
></script>
<div class="mdui-container">
    <table class="mdui-table">
        <thead>
        <tr>
            <th scope="col">服务器</th>
            <th scope="col">服务</th>
            <th scope="col">状态</th>
            <th scope="col">问题</th>
            <th scope="col">预计/修复时间</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($service['server']['name'], false); ?></td>
                <td><?php echo e($service['name'], false); ?></td>
                <td>
                    <?php if($service['status'] == 0 || $service['status'] == 2): ?>
                        🟢
                    <?php endif; ?>
                    <?php if($service['status'] == 1): ?>
                        🔴
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($service['status'] == 2): ?>
                        <span style="color: #00b44e;font-weight: 600">[已修复最近一次的问题]</span> <?php echo e($service['issue'], false); ?>

                    <?php else: ?>
                        <?php echo e($service['issue'], false); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($service['recovery'], false); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /mnt/d/Repositories/LaraWatcher/resources/views/dashboard.blade.php ENDPATH**/ ?>