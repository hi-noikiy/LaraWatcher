<?php
return [
    'labels' => [
        'ServiceTrack' => '服务异常',
    ],
    'fields' => [
        'service' => [
            'name' => '服务'
        ],
        'status' => '状态',
        'description' => '说明',
        'recovery' => '恢复时间',
    ],
    'options' => [
    ],
];
