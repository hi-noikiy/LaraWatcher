<?php
return [
    'labels' => [
        'Service' => '服务',
        'Server' => '服务器'
    ],
    'fields' => [
        'server' => [
            'name' => '服务器'
        ],
        'name' => '名称',
        'description' => '描述',
    ],
    'options' => [
    ],
];
