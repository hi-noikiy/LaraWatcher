<?php

return [
    'error_loading'    => '无法载入结果',
    'input_too_long'   => '请删除:num个字符',
    'input_too_short'  => '请输入至少:num个字符',
    'loading_more'     => '载入更多结果…',
    'maximum_selected' => '最多只能选择:num个项目',
    'no_results'       => '未找到结果',
    'searching'        => '搜索中…',
];
