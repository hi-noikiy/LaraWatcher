<?php
return [
    'labels' => [
        'Server' => '服务器',
    ],
    'fields' => [
        'name' => '名称',
        'ip' => 'IP',
        'description' => '说明',
        'location' => '位置',
    ],
    'options' => [
    ],
];
